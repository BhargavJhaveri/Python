from distutils.core import setup 

setup(
	name = 'bhargav_mac_nester',
	version = '1.4.0',
	py_modules = ['bhargav_mac_nester'],
	author = 'bhargav_jhaveri',
	author_email = 'bhargavjhaveri@gmail.com',
	url = 'http://www.wikipedia.org',
	description = 'A simple printer of nested lists built by Bhargav',
)